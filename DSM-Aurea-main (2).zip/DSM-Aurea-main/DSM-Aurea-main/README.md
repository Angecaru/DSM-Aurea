# DSM-Aurea
Backend MDE generado con OOH4RIA para NHibernate
