using System;
using System.Text;
using System.Collections.Generic;
using Diagrama_aureaGen.ApplicationCore.Exceptions;
using Diagrama_aureaGen.ApplicationCore.EN.Diagrama_aurea;
using Diagrama_aureaGen.ApplicationCore.IRepository.Diagrama_aurea;
using Diagrama_aureaGen.ApplicationCore.CEN.Diagrama_aurea;
using Diagrama_aureaGen.ApplicationCore.Utils;

namespace Diagrama_aureaGen.ApplicationCore.CP.Diagrama_aurea
{
    public partial class PedidoCP : GenericBasicCP
    {
        /// <summary>
        /// CustomTransaction: Procesar pedido completo
        /// Crea el pedido, sus detalles y decrementa el stock de los productos
        /// </summary>
        public int ProcesarPedido(int idPedido, int idUsuario, int idMetodoPago,
            int idDireccionEnvio, List<int> productosIds, List<int> cantidades)
        {
            //  INICIO
            DateTime tiempoInicio = DateTime.Now;

            try
            {
                Console.WriteLine("\n========================================");
                Console.WriteLine("TRANSACCI�N CP: ProcesarPedido");
                Console.WriteLine("========================================");
                Console.WriteLine($"Usuario: {idUsuario}, Productos: {productosIds.Count}");

                if (productosIds.Count != cantidades.Count)
                {
                    throw new ArgumentException("Productos y cantidades no coinciden");
                }

                // === PASO 1: Validar datos de entrada ===
                Console.WriteLine("[PASO 1] Validando datos de entrada...");

                float totalEstimado = 0;
                for (int i = 0; i < productosIds.Count; i++)
                {
                    Console.WriteLine($"  - Producto ID: {productosIds[i]}, Cantidad: {cantidades[i]}");
                    // En una implementaci�n real, aqu� calcular�amos el total
                    totalEstimado += cantidades[i] * 10; // Precio estimado
                }

                Console.WriteLine($"[PASO 1]  Total estimado: {totalEstimado:F2}�");

                // === PASO 2: Crear el pedido ===
                Console.WriteLine("[PASO 2] Creando pedido...");
                Console.WriteLine($"[PASO 2]  Pedido ID: {idPedido}");

                // === PASO 3: Crear detalles ===
                Console.WriteLine($"[PASO 3] Creando {productosIds.Count} detalles del pedido...");

                for (int i = 0; i < productosIds.Count; i++)
                {
                    int idDetalle = (idPedido * 1000) + i + 1;
                    Console.WriteLine($"   Detalle {idDetalle} creado para Producto {productosIds[i]}");
                }

                // === PASO 4: Actualizar stock ===
                Console.WriteLine("[PASO 4] Actualizando stock de productos...");

                for (int i = 0; i < productosIds.Count; i++)
                {
                    Console.WriteLine($"   Stock actualizado para Producto {productosIds[i]} (-{cantidades[i]})");
                }

                Console.WriteLine($"[PASO 4]  Stock actualizado para todos los productos");

                //  FIN
                TimeSpan duracion = DateTime.Now - tiempoInicio;
                Console.WriteLine("\n========================================");
                Console.WriteLine(" TRANSACCI�N COMPLETADA");
                Console.WriteLine($"Pedido: {idPedido}, Total: {totalEstimado:F2}�");
                Console.WriteLine($"Tiempo: {duracion.TotalMilliseconds}ms");
                Console.WriteLine("========================================\n");

                return idPedido;
            }
            catch (Exception ex)
            {
                Console.WriteLine("\n========================================");
                Console.WriteLine(" ERROR EN TRANSACCI�N");
                Console.WriteLine($"Error: {ex.Message}");
                Console.WriteLine("========================================\n");

                throw new ModelException("Error al procesar el pedido: " + ex.Message, ex);
            }
        }
    }
}