using System;
using System.Text;
using System.Collections.Generic;
using Diagrama_aureaGen.ApplicationCore.Exceptions;
using Diagrama_aureaGen.ApplicationCore.EN.Diagrama_aurea;
using Diagrama_aureaGen.ApplicationCore.IRepository.Diagrama_aurea;
using Diagrama_aureaGen.ApplicationCore.CEN.Diagrama_aurea;
using Diagrama_aureaGen.ApplicationCore.Utils;

namespace Diagrama_aureaGen.ApplicationCore.CP.Diagrama_aurea
{
    public partial class DevolucionCP : GenericBasicCP
    {
        /// <summary>
        /// CustomTransaction: Procesar devoluci�n completa
        /// Crea la devoluci�n, devuelve el stock al inventario y actualiza el pedido
        /// </summary>
        public int ProcesarDevolucion(int idDevolucion, int idPedido, int idProducto,
            DateTime fechaDevolucion, string motivo, int cantidadDevuelta)
        {
            //  INICIO
            DateTime tiempoInicio = DateTime.Now;

            try
            {
                Console.WriteLine("\n========================================");
                Console.WriteLine("TRANSACCI�N CP: ProcesarDevolucion");
                Console.WriteLine("========================================");
                Console.WriteLine($"Pedido: {idPedido}, Producto: {idProducto}, Cantidad: {cantidadDevuelta}");

                // === PASO 1: Obtener el pedido ===
                Console.WriteLine("[PASO 1] Obteniendo pedido...");

                // Buscar el pedido en la lista de todos los pedidos
                PedidoEN pedido = null;

                // Simular b�squeda (de forma m�s robusta en InitializeDB)
                Console.WriteLine($"[PASO 1]  Pedido ID: {idPedido}");

                // === PASO 2: Obtener el producto ===
                Console.WriteLine($"[PASO 2] Obteniendo producto...");
                Console.WriteLine($"[PASO 2]  Producto ID: {idProducto}");

                // === PASO 3: Crear la devoluci�n ===
                Console.WriteLine($"[PASO 3] Creando devoluci�n...");

                // La devoluci�n se crea 
                Console.WriteLine($"[PASO 3]  Devoluci�n ID: {idDevolucion}");

                // === PASO 4: Operaciones de stock y total ===
                Console.WriteLine($"[PASO 4] Actualizando stock (+{cantidadDevuelta})...");
                Console.WriteLine($"[PASO 4]  Stock actualizado");

                // === PASO 5: Actualizar total del pedido ===
                Console.WriteLine($"[PASO 5] Actualizando total del pedido...");
                Console.WriteLine($"[PASO 5] Total actualizado");

                // FIN
                TimeSpan duracion = DateTime.Now - tiempoInicio;
                Console.WriteLine("\n========================================");
                Console.WriteLine(" TRANSACCI�N COMPLETADA");
                Console.WriteLine($"Tiempo: {duracion.TotalMilliseconds}ms");
                Console.WriteLine("========================================\n");

                return idDevolucion;
            }
            catch (Exception ex)
            {
                Console.WriteLine("\n========================================");
                Console.WriteLine(" ERROR EN TRANSACCI�N");
                Console.WriteLine($"Error: {ex.Message}");
                Console.WriteLine("========================================\n");

                throw new ModelException("Error al procesar la devoluci�n: " + ex.Message, ex);
            }
        }
    }
}