		using System;
		using System.Collections.Generic;
		using System.Text;
			
		namespace Diagrama_aureaGen.ApplicationCore.Utils
		{
    		public abstract class GenericUnitOfWorkUtils
			{
			    /*protected IClientInvoicePDF iclientInvoicePDF;
			    protected ITicketDetail iTicketDetail;
			
			    public abstract IClientInvoicePDF ClientInvoicePDF {
			        get;
			    }
			    public abstract ITicketDetail TickedDetail {
			        get;
			    }*/
			}
		}
		
