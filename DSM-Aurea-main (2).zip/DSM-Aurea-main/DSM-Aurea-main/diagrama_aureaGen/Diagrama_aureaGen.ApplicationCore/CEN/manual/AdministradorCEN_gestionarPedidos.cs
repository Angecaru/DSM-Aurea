
using System;
using System.Text;
using System.Collections.Generic;
using Diagrama_aureaGen.ApplicationCore.Exceptions;
using Diagrama_aureaGen.ApplicationCore.EN.Diagrama_aurea;
using Diagrama_aureaGen.ApplicationCore.IRepository.Diagrama_aurea;


/*PROTECTED REGION ID(usingDiagrama_aureaGen.ApplicationCore.CEN.Diagrama_aurea_Administrador_gestionarPedidos) ENABLED START*/
//  references to other libraries
/*PROTECTED REGION END*/

namespace Diagrama_aureaGen.ApplicationCore.CEN.Diagrama_aurea
{
public partial class AdministradorCEN
{
public void GestionarPedidos (string p_oid)
{
        /*PROTECTED REGION ID(Diagrama_aureaGen.ApplicationCore.CEN.Diagrama_aurea_Administrador_gestionarPedidos) ENABLED START*/

        // Write here your custom code...

        throw new NotImplementedException ("Method GestionarPedidos() not yet implemented.");

        /*PROTECTED REGION END*/
}
}
}
