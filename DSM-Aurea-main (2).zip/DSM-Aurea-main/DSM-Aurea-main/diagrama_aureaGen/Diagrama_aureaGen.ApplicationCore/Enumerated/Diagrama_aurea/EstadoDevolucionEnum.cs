
using System;

namespace Diagrama_aureaGen.ApplicationCore.Enumerated.Diagrama_aurea
{
public enum EstadoDevolucionEnum { Aceptada=1, Rechazada=2 };
}
