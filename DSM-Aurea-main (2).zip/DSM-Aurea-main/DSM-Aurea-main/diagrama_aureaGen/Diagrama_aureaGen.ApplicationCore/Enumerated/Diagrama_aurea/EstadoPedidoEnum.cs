
using System;

namespace Diagrama_aureaGen.ApplicationCore.Enumerated.Diagrama_aurea
{
public enum EstadoPedidoEnum { EnCarrito=1, Pendiente=2, EnProceso=3, Enviado=4, Entregado=5, Cancelado=6 };
}
