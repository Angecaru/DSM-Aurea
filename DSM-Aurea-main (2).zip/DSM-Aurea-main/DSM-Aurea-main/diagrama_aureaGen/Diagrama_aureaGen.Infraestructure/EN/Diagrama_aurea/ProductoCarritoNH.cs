
using System;
using Diagrama_aureaGen.ApplicationCore.EN.Diagrama_aurea;
namespace Diagrama_aureaGen.Infraestructure.EN.Diagrama_aurea
{
public partial class ProductoCarritoNH : ProductoCarritoEN {
public ProductoCarritoNH ()
{
}

public ProductoCarritoNH (ProductoCarritoEN dto) : base (dto)
{
}
}
}
