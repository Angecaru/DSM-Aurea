
using System;
using Diagrama_aureaGen.ApplicationCore.EN.Diagrama_aurea;
namespace Diagrama_aureaGen.Infraestructure.EN.Diagrama_aurea
{
public partial class ProductoNH : ProductoEN {
public ProductoNH ()
{
}

public ProductoNH (ProductoEN dto) : base (dto)
{
}
}
}
