
using System;
using Diagrama_aureaGen.ApplicationCore.EN.Diagrama_aurea;
namespace Diagrama_aureaGen.Infraestructure.EN.Diagrama_aurea
{
public partial class DeTemporadaNH : DeTemporadaEN {
public DeTemporadaNH ()
{
}

public DeTemporadaNH (DeTemporadaEN dto) : base (dto)
{
}
}
}
