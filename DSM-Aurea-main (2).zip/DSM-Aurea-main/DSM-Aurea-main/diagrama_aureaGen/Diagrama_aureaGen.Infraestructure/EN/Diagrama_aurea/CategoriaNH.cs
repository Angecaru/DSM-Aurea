
using System;
using Diagrama_aureaGen.ApplicationCore.EN.Diagrama_aurea;
namespace Diagrama_aureaGen.Infraestructure.EN.Diagrama_aurea
{
public partial class CategoriaNH : CategoriaEN {
public CategoriaNH ()
{
}

public CategoriaNH (CategoriaEN dto) : base (dto)
{
}
}
}
